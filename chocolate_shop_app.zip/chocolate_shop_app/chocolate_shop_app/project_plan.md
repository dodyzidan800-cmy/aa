# خطة مشروع تطبيق متجر الشوكولاتة (Android Studio & Java)

## 1. تحليل المتطلبات

| الميزة | الوصف | الدور | التكنولوجيا |
| :--- | :--- | :--- | :--- |
| **شاشة البداية (Splash)** | عرض شعار التطبيق وتحميل سريع. | عام | Activity |
| **تسجيل الدخول** | للتاجر فقط (Admin). | التاجر | Firebase Authentication |
| **الواجهة الرئيسية** | عرض عروض (Slider) وقائمة منتجات (RecyclerView). | المستخدم | Activity, RecyclerView |
| **تفاصيل المنتج** | عرض تفاصيل المنتج وإمكانية الحجز. | المستخدم | Activity |
| **نافذة الحجز** | إدخال بيانات الحجز (الاسم، الهاتف، الكمية، وقت الاستلام). | المستخدم | Dialog/Fragment |
| **صفحة الطلبات** | قائمة بالطلبات الجديدة مع أزرار قبول/رفض. | التاجر | Activity, RecyclerView |
| **قاعدة البيانات** | تخزين المنتجات والطلبات. | عام | Firebase Realtime Database |

## 2. بنية قاعدة البيانات (Firebase Realtime Database)

سيتم استخدام عقدتين رئيسيتين:

1.  **`Products` (المنتجات):**
    ```json
    {
      "productId_1": {
        "name": "Dark Chocolate",
        "price": 10.0,
        "desc": "Premium 70% cocoa.",
        "stock": 15,
        "imageUrl": "url_to_image_1",
        "weight": "100g"
      },
      // ...
    }
    ```

2.  **`Orders` (الطلبات):**
    ```json
    {
      "orderId_1": {
        "customerName": "Ali",
        "phone": "091xxxxxxx",
        "productName": "Milk Chocolate",
        "qty": 2,
        "pickupTime": "5 PM",
        "status": "Pending" // يمكن أن تكون "Accepted" أو "Rejected"
      },
      // ...
    }
    ```

## 3. المكونات الرئيسية للتطبيق (Activities & Data Models)

| المكون | النوع | الوصف |
| :--- | :--- | :--- |
| `SplashActivity.java` | Activity | شاشة البداية. |
| `HomeActivity.java` | Activity | الواجهة الرئيسية للمستخدم. |
| `ProductDetailActivity.java` | Activity | عرض تفاصيل المنتج. |
| `LoginActivity.java` | Activity | شاشة تسجيل دخول التاجر. |
| `AdminOrdersActivity.java` | Activity | عرض وإدارة الطلبات. |
| `Product.java` | Data Model | نموذج بيانات للمنتج. |
| `Order.java` | Data Model | نموذج بيانات للطلب. |
| `ProductAdapter.java` | Adapter | محول لعرض المنتجات في `RecyclerView`. |
| `OrderAdapter.java` | Adapter | محول لعرض الطلبات في `RecyclerView`. |
| `BookingDialog.java` | DialogFragment | نافذة منبثقة لإدخال تفاصيل الحجز. |

## 4. الاعتمادات الأساسية (Dependencies)

سيتم إضافة الاعتمادات التالية إلى ملف `build.gradle (app)`:

*   `implementation 'com.google.firebase:firebase-database'` (لقاعدة البيانات)
*   `implementation 'com.google.firebase:firebase-auth'` (لتسجيل دخول التاجر)
*   `implementation 'androidx.recyclerview:recyclerview'` (لقوائم المنتجات والطلبات)
*   `implementation 'com.github.bumptech.glide:glide'` (لتحميل وعرض الصور)
*   `implementation 'androidx.viewpager2:viewpager2'` (لشريط العروض Slider)

## 5. ملاحظات التصميم واللغة

*   **اللغة:** Java.
*   **التنسيق:** سيتم استخدام تنسيق RTL (من اليمين إلى اليسار) لدعم اللغة العربية.
*   **الصور والتنسيقات:** سيتم توفير ملفات XML للتنسيقات (Layouts) وملفات Java (Activities, Adapters, Models) كاملة.
*   **الصور:** سيتم الإشارة إلى أماكن وضع الصور (Drawable) أو استخدام روابط صور وهمية (Placeholders) في الكود.

---
**نهاية المرحلة الأولى: تحليل وتصميم.**
