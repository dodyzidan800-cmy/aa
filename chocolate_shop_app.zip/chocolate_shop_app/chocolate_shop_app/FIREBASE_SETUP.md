# إعداد Firebase لتطبيق متجر الشوكولاتة

## خطوات الإعداد

### 1. إنشاء مشروع Firebase جديد

1.  اذهب إلى [Firebase Console](https://console.firebase.google.com/)
2.  انقر على "إنشاء مشروع جديد" (Create a new project)
3.  أدخل اسم المشروع: **chocolate-shop-app**
4.  اتبع الخطوات لإنشاء المشروع

### 2. إضافة تطبيق Android

1.  في Firebase Console، انقر على "إضافة تطبيق" (Add app)
2.  اختر **Android**
3.  أدخل اسم الحزمة: **com.example.chocolateshop**
4.  قم بتحميل ملف **google-services.json** وضعه في مجلد `app/` من المشروع

### 3. تفعيل Firebase Realtime Database

1.  في Firebase Console، اذهب إلى **Realtime Database**
2.  انقر على **إنشاء قاعدة بيانات** (Create Database)
3.  اختر **وضع الاختبار** (Test Mode) للبداية
4.  اختر الموقع الجغرافي الأقرب

### 4. تفعيل Firebase Authentication

1.  في Firebase Console، اذهب إلى **Authentication**
2.  انقر على **Get Started**
3.  فعّل **Email/Password** للتاجر

### 5. إضافة بيانات تجريبية

في Firebase Console، انقر على **Realtime Database** وأضف البيانات التالية:

```json
{
  "Products": {
    "product_1": {
      "name": "Dark Chocolate",
      "price": 10.0,
      "desc": "Premium 70% cocoa",
      "stock": 15,
      "imageUrl": "https://via.placeholder.com/200",
      "weight": "100g"
    },
    "product_2": {
      "name": "Milk Chocolate",
      "price": 8.0,
      "desc": "Smooth milk chocolate",
      "stock": 20,
      "imageUrl": "https://via.placeholder.com/200",
      "weight": "100g"
    },
    "product_3": {
      "name": "White Chocolate",
      "price": 9.0,
      "desc": "Creamy white chocolate",
      "stock": 10,
      "imageUrl": "https://via.placeholder.com/200",
      "weight": "100g"
    }
  }
}
```

### 6. إنشاء حساب تاجر

1.  في Firebase Console، اذهب إلى **Authentication** > **Users**
2.  انقر على **Add User**
3.  أدخل البريد الإلكتروني والكلمة المرورية (مثال: `admin@chocolateshop.com` / `password123`)

## ملاحظات مهمة

*   **قواعد الأمان:** في الإنتاج، تأكد من تحديث قواعد الأمان في Firebase لحماية البيانات.
*   **صور المنتجات:** يمكنك استخدام صور من Firebase Storage أو روابط خارجية.
*   **الإشعارات:** يمكن إضافة Firebase Cloud Messaging (FCM) لإرسال إشعارات للعملاء عند قبول/رفض الطلبات.

---
**نهاية إعداد Firebase.**
