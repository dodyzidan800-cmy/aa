package com.example.chocolateshop;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

/**
 * محول (Adapter) لعرض قائمة الطلبات في RecyclerView.
 */
public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private Context context;
    private List<Order> orderList;
    private DatabaseReference databaseReference;

    public OrderAdapter(Context context, List<Order> orderList) {
        this.context = context;
        this.orderList = orderList;
        this.databaseReference = FirebaseDatabase.getInstance().getReference("Orders");
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orderList.get(position);

        holder.customerName.setText("العميل: " + order.getCustomerName());
        holder.phone.setText("الهاتف: " + order.getPhone());
        holder.productName.setText("المنتج: " + order.getProductName());
        holder.quantity.setText("الكمية: " + order.getQty());
        holder.pickupTime.setText("وقت الاستلام: " + order.getPickupTime());
        holder.status.setText("الحالة: " + order.getStatus());

        // تحديد لون الحالة
        if ("Pending".equals(order.getStatus())) {
            holder.status.setTextColor(context.getResources().getColor(android.R.color.holo_orange_dark));
        } else if ("Accepted".equals(order.getStatus())) {
            holder.status.setTextColor(context.getResources().getColor(android.R.color.holo_green_dark));
        } else if ("Rejected".equals(order.getStatus())) {
            holder.status.setTextColor(context.getResources().getColor(android.R.color.holo_red_dark));
        }

        // إظهار/إخفاء الأزرار بناءً على الحالة
        if ("Pending".equals(order.getStatus())) {
            holder.acceptButton.setVisibility(View.VISIBLE);
            holder.rejectButton.setVisibility(View.VISIBLE);
        } else {
            holder.acceptButton.setVisibility(View.GONE);
            holder.rejectButton.setVisibility(View.GONE);
        }

        // عند النقر على زر القبول
        holder.acceptButton.setOnClickListener(v -> updateOrderStatus(order.getOrderId(), "Accepted"));

        // عند النقر على زر الرفض
        holder.rejectButton.setOnClickListener(v -> updateOrderStatus(order.getOrderId(), "Rejected"));
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    /**
     * تحديث حالة الطلب في Firebase.
     */
    private void updateOrderStatus(String orderId, String newStatus) {
        databaseReference.child(orderId).child("status").setValue(newStatus).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(context, "تم تحديث الحالة إلى: " + newStatus, Toast.LENGTH_SHORT).show();
                notifyDataSetChanged();
            } else {
                Toast.makeText(context, "حدث خطأ في التحديث", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * ViewHolder لعنصر الطلب.
     */
    public static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView customerName;
        TextView phone;
        TextView productName;
        TextView quantity;
        TextView pickupTime;
        TextView status;
        Button acceptButton;
        Button rejectButton;
        CardView cardView;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            customerName = itemView.findViewById(R.id.order_customer_name);
            phone = itemView.findViewById(R.id.order_phone);
            productName = itemView.findViewById(R.id.order_product_name);
            quantity = itemView.findViewById(R.id.order_quantity);
            pickupTime = itemView.findViewById(R.id.order_pickup_time);
            status = itemView.findViewById(R.id.order_status);
            acceptButton = itemView.findViewById(R.id.order_accept_button);
            rejectButton = itemView.findViewById(R.id.order_reject_button);
            cardView = itemView.findViewById(R.id.order_card);
        }
    }
}
