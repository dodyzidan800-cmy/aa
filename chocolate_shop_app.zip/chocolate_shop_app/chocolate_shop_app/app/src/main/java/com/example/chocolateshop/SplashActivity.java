package com.example.chocolateshop;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

/**
 * شاشة البداية (Splash Screen) - تعرض شعار التطبيق لمدة قصيرة ثم تنتقل للشاشة الرئيسية.
 */
public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_DURATION = 2000; // مدة العرض بالميلي ثانية (ثانيتان)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // استخدام Handler للانتظار ثم الانتقال للشاشة الرئيسية
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Intent intent = new Intent(SplashActivity.this, HomeActivity.class);
            startActivity(intent);
            finish(); // إغلاق SplashActivity
        }, SPLASH_DURATION);
    }
}
