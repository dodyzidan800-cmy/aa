package com.example.chocolateshop;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * نافذة الحجز (DialogFragment) - لإدخال تفاصيل الحجز.
 */
public class BookingDialog extends DialogFragment {

    private EditText nameInput;
    private EditText phoneInput;
    private EditText quantityInput;
    private EditText pickupTimeInput;
    private Button confirmButton;
    private Button cancelButton;

    private String productName;
    private DatabaseReference databaseReference;

    public BookingDialog(String productName) {
        this.productName = productName;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_booking, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // ربط العناصر
        nameInput = view.findViewById(R.id.booking_name_input);
        phoneInput = view.findViewById(R.id.booking_phone_input);
        quantityInput = view.findViewById(R.id.booking_quantity_input);
        pickupTimeInput = view.findViewById(R.id.booking_pickup_time_input);
        confirmButton = view.findViewById(R.id.confirm_booking_button);
        cancelButton = view.findViewById(R.id.cancel_booking_button);

        databaseReference = FirebaseDatabase.getInstance().getReference("Orders");

        // عند النقر على زر التأكيد
        confirmButton.setOnClickListener(v -> submitBooking());

        // عند النقر على زر الإلغاء
        cancelButton.setOnClickListener(v -> dismiss());
    }

    /**
     * إرسال الحجز إلى Firebase.
     */
    private void submitBooking() {
        String name = nameInput.getText().toString().trim();
        String phone = phoneInput.getText().toString().trim();
        String quantityStr = quantityInput.getText().toString().trim();
        String pickupTime = pickupTimeInput.getText().toString().trim();

        // التحقق من صحة المدخلات
        if (name.isEmpty() || phone.isEmpty() || quantityStr.isEmpty() || pickupTime.isEmpty()) {
            Toast.makeText(getContext(), "يرجى ملء جميع الحقول", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity = Integer.parseInt(quantityStr);

        // إنشاء طلب جديد
        String orderId = databaseReference.push().getKey();
        Order order = new Order(orderId, name, phone, productName, quantity, pickupTime, "Pending");

        // حفظ الطلب في Firebase
        databaseReference.child(orderId).setValue(order).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(getContext(), "تم الحجز بنجاح! سيتم الاتصال بك قريباً", Toast.LENGTH_SHORT).show();
                dismiss();
            } else {
                Toast.makeText(getContext(), "حدث خطأ في الحجز", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
