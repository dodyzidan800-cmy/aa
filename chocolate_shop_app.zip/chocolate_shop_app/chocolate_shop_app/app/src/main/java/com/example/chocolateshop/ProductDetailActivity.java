package com.example.chocolateshop;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

/**
 * شاشة تفاصيل المنتج - عرض معلومات كاملة عن المنتج والحجز.
 */
public class ProductDetailActivity extends AppCompatActivity {

    private ImageView productImage;
    private TextView productName;
    private TextView productPrice;
    private TextView productDesc;
    private TextView productWeight;
    private TextView productStock;
    private Button bookNowButton;

    private String productId;
    private String name;
    private double price;
    private String desc;
    private int stock;
    private String imageUrl;
    private String weight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        // ربط العناصر
        productImage = findViewById(R.id.product_detail_image);
        productName = findViewById(R.id.product_detail_name);
        productPrice = findViewById(R.id.product_detail_price);
        productDesc = findViewById(R.id.product_detail_desc);
        productWeight = findViewById(R.id.product_detail_weight);
        productStock = findViewById(R.id.product_detail_stock);
        bookNowButton = findViewById(R.id.book_now_button);

        // استقبال البيانات من Intent
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            productId = extras.getString("productId");
            name = extras.getString("productName");
            price = extras.getDouble("productPrice");
            desc = extras.getString("productDesc");
            stock = extras.getInt("productStock");
            imageUrl = extras.getString("productImageUrl");
            weight = extras.getString("productWeight");
        }

        // عرض البيانات
        displayProductDetails();

        // عند النقر على زر "احجز الآن"
        bookNowButton.setOnClickListener(v -> {
            // فتح نافذة الحجز
            BookingDialog bookingDialog = new BookingDialog(name);
            bookingDialog.show(getSupportFragmentManager(), "BookingDialog");
        });
    }

    /**
     * عرض تفاصيل المنتج.
     */
    private void displayProductDetails() {
        productName.setText(name);
        productPrice.setText("السعر: " + price + " ريال");
        productDesc.setText("الوصف: " + desc);
        productWeight.setText("الوزن: " + weight);
        productStock.setText("المخزون: " + stock + " وحدة");

        // تحميل الصورة
        Glide.with(this)
                .load(imageUrl)
                .placeholder(R.drawable.ic_placeholder)
                .into(productImage);
    }
}
