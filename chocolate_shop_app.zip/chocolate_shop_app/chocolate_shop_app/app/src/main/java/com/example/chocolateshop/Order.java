package com.example.chocolateshop;

/**
 * نموذج بيانات للطلب.
 */
public class Order {
    private String orderId;
    private String customerName;
    private String phone;
    private String productName;
    private int qty;
    private String pickupTime;
    private String status; // "Pending", "Accepted", "Rejected"

    // Constructor الفارغ (مطلوب من Firebase)
    public Order() {
    }

    // Constructor الكامل
    public Order(String orderId, String customerName, String phone, String productName, int qty, String pickupTime, String status) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.phone = phone;
        this.productName = productName;
        this.qty = qty;
        this.pickupTime = pickupTime;
        this.status = status;
    }

    // Getters and Setters
    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public String getPickupTime() {
        return pickupTime;
    }

    public void setPickupTime(String pickupTime) {
        this.pickupTime = pickupTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
